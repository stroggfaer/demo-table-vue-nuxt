export const dpr = window.devicePixelRatio || 1;
export default {
  dpr
};
