<template>
  <div class="admin-layout-wrap">
    <Nuxt />
  </div>
</template>


<style lang="scss">
 .admin-layout-wrap {
  // max-width: 1440px;
  //height: 100%;
  min-width: 375px;
  overflow: hidden;
  height: 100vh; // sroll
  //max-width: 1200px; // 1376
  margin: auto;
  padding: 0px;
}
</style>
