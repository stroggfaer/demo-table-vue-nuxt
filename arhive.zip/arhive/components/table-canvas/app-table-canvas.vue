<template>
  <div>
<!--    <pre>{{cord}}</pre>-->
<!--    <pre>isDrawingMouseEnter: {{isDrawingMouseEnter}}</pre>-->
<!--    ++{{widthColumns}}++-->
    <div class="xs-data-grid">
      <div  id='containerCanvas' :style="{ width: `${widthColumns}px`}" v-loading="loading" ref="refCanvas"></div>
      <div
        :class="`xs-data-grid-overlayer`"
        :style="{ top: `${tableHeaderHeight }px` }"
      >
        <div v-show="show" :class="`xs-data-grid-editor`" ref="editor">
          <div  class="popover-cell"
                v-if="dataType === 'text'"
                :style="{width: `${this.options.canvas_cell_w -1}px`, height: `${this.options.canvas_row_height -1}px`}"
          >
            <el-input
              ref="el_input"
              placeholder=""
              v-model="value"
              size="small" :maxlength="2"
              class="input_edit"
              :class="{error: isErrorInput}"
            ></el-input>
          </div>

          <div class="popover-cell" v-if="dataType === 'active'">
            <pre>{{focusCell}}</pre>
          </div>
        </div>
      </div>
      <!--Icons svg-->
      <svg id="circleIcons" width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="6" cy="5.5" r="5" fill="#123123" stroke="black" stroke-opacity="0.5"/>
      </svg>
      <!--Icons svg-->
      <svg id="bgBox" width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="30" height="30" rx="5" fill="#123123" fill-opacity="0.2"/>
      </svg>
    </div>
  </div>


</template>

<script>

import {
  icons,
  levelBg,
  levelBorder,
  levelBgRow,
  planBorder,
  headerLevelBorder,
  departmentBorder
} from '../../core_table/Style';

// import CanvasTable from "x-canvas-table";
import CanvasTable from 'x-canvas-table'
import {mapGetters} from "vuex";

import {VIEW_PORT_HEIGHT, VIEW_PORT_WIDTH} from "../../store";
import moment from "moment";

export default {
  props: {
    loading:  { type: Boolean, default: false },
    dataGrid:  { type: Array},
    dateCurrent:  { type: String, default: '2022-01-22' },
  },
  components: { CanvasTable },

  data() {
    return {
      // Запрос с бэка;
      dataResult: [],
      //   daysTotal: headerDays().map((item,ind) => ({ total:item, key:ind, value: `${item}` })),
      focusCell: null,
      show: false,
      value: "",
      popWidth: "auto",
      dataType: "text",
      cellOn: null,
      hover: [],
      columns: [],
      dataTable: [],
      toggle: [],
      isDrawing: false,
      isDrawingMouseEnter: false,
      cord: {
        x: 0,
        y: 0,
        w: 0,
        h: 0,
        day: 0,
        key: '',
        days: []
      },
      isCellHover: null,
      widthColumns: 1500, // Динамические вычечление
      heightRow: 0,
      key: 0,
      //Настройки таблицы;
      options: {
        canvas_cell_w: 40, // Размер ячейки;
        canvas_columns_width: 250,
        canvas_header_height: 40,
        canvas_row_height: 40
      }
    };
  },

  computed: {

    isErrorInput() {
      return this.value !== '' && !this.isNumeric(this.value)
    },

    tableHeaderHeight() {
      return -1;
    },
    ...mapGetters({
      viewHeight: VIEW_PORT_HEIGHT,
      viewWidth: VIEW_PORT_WIDTH
    }),

    popupSty() {
      return {
        width: this.popWidth,
        top: "-1px"
      };
    },

  },

  methods: {

    svgIconsBase64(idElement, colorEnd, colorStart ='#123123') {
      const element = document.querySelector(`#${idElement}`);
      let res = ''
      if (element) {
        const s = new XMLSerializer().serializeToString(element)
        const colorRep = s.replace(colorStart, colorEnd);
        const encodedData = window.btoa(colorRep);
        res = 'data:image/svg+xml;base64,' + encodedData;
      }
      return res;
    },

    //Календар колечество дней;
    headerDays(d = 1, slice = false,left = false) {
      const m = moment(this.dateCurrent, "YYYY-MM").daysInMonth();
      this.widthColumns = `${(this.options.canvas_columns_width + this.options.canvas_cell_w * m) + 10}`;
      const result  = []
      if(slice) {
        for (let i = 1; i <= m; ++i) {
          if(left) {
            if(i <= d) {
              result.push(i);
            }
          }else{
            if(i >= d) {
              result.push(i);
            }
          }

        }
      }else{
        for (let i = 1; i <= m; ++i) {
          result.push(i);
        }
      }
      return result;
    },

    //Вычесление размер общего клоичесво ячейки
    moveCell(dayCurrent, left = false) {
      if(!this.cellOn) return false;
      const day = this.cord.day;
      const res = this.headerDays(day,true,left);
      const temp = [];

      res.forEach((d,i)=>{
        if(left) {
          if(d >= dayCurrent) {
            temp.push(d)
          }
        }else{
          if(d <= dayCurrent) {
            temp.push(d)
          }
        }

      })
      return {
        widthCol: this.options.canvas_cell_w * temp.length,
        sliceDays: temp
      }
    },

    // Обработка массив;
    generatePersons(init = false) {
      let obj = [];
       this.dataResult.forEach((department, index) => {
         obj.push({
           row: {
             name: department.name,
             level: 1,
             row: index,
             type: 'department',
             result: department.result
           },
         })
          department.employee.forEach((employee, idx) => {
              obj.push({
                  row: {
                    id: employee.id,
                    parentId: department.id,
                    name: employee.name,
                    open: employee.open,
                    level: 2,
                    row: idx,
                    type: 'employee',
                    result: employee.result,
                    isPlan: Boolean(employee.plan.length)
                  },
              })

              if(employee.open === true && init === true) this.toggle[employee.id] = employee.open

               if(this.toggle[employee.id] === true) {
                 employee.plan.forEach((plan, i) => {
                   obj.push({
                     row: {
                       index: i,
                       id: plan.id,
                       name: plan.name,
                       parentId: employee.id,
                       departmentId:  department.id,
                       level: 3,
                       row: idx,
                       type: 'plan',
                       key: `${index}_${idx}_${i}`,
                       sort: plan.sort,
                       result: plan.result,
                       ...plan
                     },
                   })
                 });
               }

          })
       });
      return obj;
    },

    // глобальный доступ;
    onCellClick(e, name) {
      // window.eventClickTable = e;
      // console.log('__onCellClick',e);
      // console.log('name',name);
      // const row = e.path.find( (e) => e)
      // const cell = e.path.find( (e) => e)
      // // console.log('row', row);
      // // console.log('cell', cell);
      // //console.log('onCellClick',e);
      // const target = e.target;
      // this.focusCell = target;
      // this.showEditor();
      // this.updateTable();
    },

    configTable(el) {
      return {
        container: el,
        columns: this.columns,
        style: {
          rowHeight: this.options.canvas_row_height,
          height: '100%',
          width: '100%', //1510
          borderColor: 'rgba(255,255,255,0)',
          fontFamily: 'Gilroy',
          padding: 0,
          headerBackColor: 'rgba(249, 250, 251, 1)',  //'rgba(249, 250, 251, 1)',
          headerRowHeight: this.options.canvas_header_height
        },
        onRow: (record, rowIndex) => {

        },
        onScrollLoad: (record, rowIndex) => {
          console.log('onScrollLoad',record);
        },
        scrollLoadHeight: (record) => {
          console.log('scrollLoadHeight',record);
        }
      }
    },

    heightRowSize() {
      return this.heightRow = `${(this.options.canvas_header_height + this.options.canvas_row_height * this.dataTable.length) + 10}`;
    },

    async load () {

      const w  = window;
      const el = document.getElementById('containerCanvas');
      el.innerHTML = ''
      const ct = new CanvasTable(this.configTable(el));
     // ct.ctx = ct.canvas.getContext('2d', { alpha: true });
      //   this.heightRow = `${(this.options.canvas_header_height + this.options.canvas_row_height * m) + 10}`;
      // const test =  ct.canvas.getContext('2d', { alpha: false });
      // ct.rows.
      w.ct = ct
      ct.source = this.dataTable
      // setTimeout(()=>{
      //    this.drawRect(100, 60, 1000, 40, {
      //     fillColor: 'rgba(4,4,5,0.2)',
      //     borderColor: 'rgb(12,76,222)',
      //     borderWidth: 1.3
      //   },ct);
      // },1000)


      w.onCellClick = this.onCellClick

  //  ct.render();
      //ct.resize();
     // await this.$nextTick()
     //ct.ctx.fillRect(0, 0, ct.canvas.width, ct.canvas.height);
     // ct.ctx.lineWidth = 'rgba(249, 250, 251, 1)';
      console.log('__containerCanvas__',ct)
  // CanvasTable
      // ct.body.render();
      // ct.header.render();



      // ctScale( ct )
     // const conts = ct.canvas.getContext('2d');
     //  console.log(conts)
     //  conts.clearRect(0, 0, ct.canvas.width, ct.canvas.height);
     //  ct.canvas.style.background = "red";
     //  // conts.strokeStyle = 'rgba(250,0,0,0.5)';
     //  // conts.fillRect(0,0,ct.canvas.width,ct.canvas.height)

      //  ct.ctx.fillRect(0,0,window.innerWidth,window.innerHeight);

    //  w.ct.ctx.shadowColor = "rgba(203,10,10,9)"
     // w.ct.ctx.strokeStyle = "rgba(255,255,255,9)"
      //ct.resize()
      //strokeStyle
      // ct.globalAlpha = 1
      // ct.globalCompositeOperation = "lighter";
    },

    async updateTable (force = false) {
   //   const el = this.$el
      const w = window
      const ct = w.ct
      if ( !ct ) {
        return
      }
     // ct.props = this.configTable(el)
      this.dataTable = this.generatePersons();
      ct.source = this.dataTable;
      this.heightRowSize()
    //  ct.resize();
    },

    renderCell({data, record}) {
      const $this = this;
      // название;
      let titleContent = []
      // Разбивка по строку;
      if(data) {
        switch (data.type) {
          case 'department':
            const el = document.getElementById('containerCanvas');
            const widthWindow  = el.offsetWidth / 4 || 200;
            titleContent = [
              new CanvasTable.Text({
                text: data.name,
                style: {
                  color: '#F9FAFB',
                  fontSize: '16px',
                  fontWeight: 'bold',
                  left: widthWindow, //widthWindow
                  zIndex:300,
                },
                event: {
                  onMouseEnter: (e) => {
                    this.clearLineDrawRect();
                  }
                },
              })
            ]
            break;
          case 'employee':
            titleContent = [
              new CanvasTable.Svg({
                path: icons['plus'],
                style: {
                  top: 0.5,
                  left: 1,
                  width: 25,
                  height: 35,
                  color: 'transparent',
                  border:'transparent',
                },
                event: {
                  onClick: (e,r) => {
                    const w = window
                    const ct = w.ct
                    // Добавить отдел;
                    this.addPlan(data);
                    this.updateTable();
                  },
                  onMouseEnter: (e) => {
                    //x-canvas-scroll
                    const el = document.querySelector(".x-canvas-scroll");
                    const w = window
                    el.style.cursor = 'pointer';
                  },
                  onMouseLeave: (e) => {
                    const el = document.querySelector(".x-canvas-scroll");
                    el.style.cursor = 'default';
                  },
                  onDoubleClick: (event) => {
                    console.log('onDoubleClick',event);
                  }, // Double Click
                  onContextMenu: (event) => {
                    console.log('onContextMenu',event);
                  }
                }
              }),
              new CanvasTable.Text({
                text: data.name,
                style: {
                  width: 120,
                  fontWeight:'bold',
                  fontSize: '16px',
                  padding: [0, 0, 0, 0],
                  //   backgroundColor: '#AAC9F2'
                },
              }),
              $this.iconArrow(data,record),
              new CanvasTable.Text({
                text: $this.totalSum(record.row.result), //data,
                style: {
                  align: 'right',
                  width: 50,
                  fontWeight:'bold',
                  padding: [0,0, 0, 0],
                  //   backgroundColor: '#AAC9F2'
                },
              }),
            ]
            break;
          case 'plan':
            const w  = window;
           // w.ct = ct.ctx
           //TODO: mod;
           const circleIcon = this.svgIconsBase64('circleIcons',`${data.color}`);
            titleContent = [
              new CanvasTable.Layer({
                width: 200,
                style: {
                  padding: [0,0,0,8],
                },
                children: [
                  new CanvasTable.Svg({
                    path: circleIcon,
                    //  path: '/icons/ellipse.svg', //'/icons/ellipse.svg',
                    width: 2,
                    style: {
                      width: 15,
                      height: 14,
                      color: '',
                      padding: 0,
                    },
                  }),
                  new CanvasTable.Text({
                    style: {
                      width: 190,
                      padding: [0, 0, 0, 8]
                    },
                    text: data.name
                  }),
                  new CanvasTable.Text({
                    text:$this.totalSum(record.row.result) // всего TODO: //
                  }),
                ]
              }),
            ]
            break;
        }
      }

      return new CanvasTable.Layer({
        // gutter: 10,
        style: {
          // border:'transparent',
          left: 0,
          border: levelBorder(data.type,data)
        },
        children: [
          new CanvasTable.Layer({
            gutter: 5,
            style: {
              border: 'transparent',
              padding: [0,5,0,0],
              backgroundColor: levelBg(data.type)
            },
            children: titleContent
          })
        ],
        event: {
          onClick: (e) => {}
        },
      })
    },

    showEditor() {

      if(!this.focusCell) return

      const {
        left,
        top,
        width,
        height
      } = this.focusCell
      this.show = true;
      this.isDrawing = false;
      // Черновой вариант;
      switch (this.dataType) {
        case 'month':
        case 'date':
        case 'datetime':
          if (isNaN(this.focusCell.text) && !isNaN(Date.parse(this.focusCell.text))) {
            this.value = this.focusCell.text;

          } else {
            this.value = "";
          }
          break
        case 'text' :
          this.value = this.focusCell.text;
          setTimeout(()=>{
            this.$refs.el_input.focus();
          },100)
          this.isDrawing = false;
          break
        case 'hover':
        case 'active':
          console.log('active');
          //
          this.value = this.focusCell.text;
          this.dataType = "active";
          break
        default:
          //
          break
      }

      this.$refs.editor.style.left = `${left - 4}px`    //`${x - 1}px`;
      this.$refs.editor.style.top = `${top}px`  //.`${y - 2 - this.tableHeaderHeight}px`;
      this.popWidth = `${width - 3}px`;
    },

    addPlan (data) {
       const department  = this.dataResult.find(it => it.id === data.parentId) || null;
       // черновой вариант;
       if(department) {
         const emp  = department.employee.find(it => it.id === data.id) || null;
         if(emp) {
           emp.plan.unshift({
             id: Math.trunc(Math.random() * (200) + 6,),
             name: 'Проект нов',
             sort: 1,
             color: '#281e25',
             parentId: emp.id,
             result: []
           })
         }
         // console.log('addPlan',emp.plan);
       }
    },

    hideEditor() {
      this.show = false;
      this.focusCell = null
      this.value = ''
      if(this.$refs.editor) {
        this.$refs.editor.style.left = "-10000px";
        this.$refs.editor.style.top = "-10000px";
      }
      this.dataType = 'text';
     // this.cellOn = null;
    },

    handleScroll (event) {
      if([...event.target.classList].includes('x-canvas-scroll-inner')) {
         if (event && event.ctrlKey ) {
        //  // return event.preventDefault()
            return false
         }
        this.hideEditor();
        this.show = false;
      }
    },

    //Иконки
    iconArrow(data,record) {
      let svgIcon = [];
      if(data && data.isPlan) {
        svgIcon = [new CanvasTable.Svg({
          //  icons['checkboxPlus'],
          path: this.toggle[data.id] ? icons['arrow_down'] : icons['arrow_left'],
          style: {
            left: 3,
            width: this.toggle[data.id] ? 15 : 9,
            height: this.toggle[data.id] ? 10 : 14,
            color: '#1890ff',
          },
          event: {
            onClick: (e,r) => {
              this.toggle[data.id] = !this.toggle[data.id];
              this.updateTable();
            },
            onMouseEnter: (e) => {
              //x-canvas-scroll
              const el = document.querySelector(".x-canvas-scroll");
              el.style.cursor = 'pointer';
            },
            onMouseLeave: (e) => {
              const el = document.querySelector(".x-canvas-scroll");
              el.style.cursor = 'default';
            },
          }
        })]
      }
      return new CanvasTable.Layer({
        style: {
          width: 20
        },
        children: svgIcon
      })
    },

    // Обработки ячейке таблицы
    cellField (obj,bg,day) {
      if (!obj.row) return null
      let result = null
      const $this = this;
      let countCell = 0;
      switch (obj.row.type) {
        case 'department':
          // Первый слой фон;
          result = new CanvasTable.Layer({
            style: {
              border: departmentBorder,//departmentBorder  //#9EA7C5
              backgroundColor: bg,
              zIndex: -1
            },
            children: [
              // Второй слой фон;
              new CanvasTable.Layer({
                style: {
                  backgroundColor: 'rgba(115, 129, 163, 0.5)',
                  zIndex: -1
                }
              })
            ]
          })
          break;
        case 'employee':
          const cell = obj.row.result.find(item => item.day === day) || null;
          if(!cell) return null
          let layerValue = {}

          if (cell.icon) {
            layerValue = new CanvasTable.Svg({
              //  icons['checkboxPlus'],
              path: icons[cell.icon], // sum // close // box
              style: {
                color: 'transparent',
                left: 5,
                top: 1,
                width: 20,
                height: 20,
                align: 'center'
              },
            })
          }else{
            // TODO: Сотрудник значение;
            layerValue = new CanvasTable.Text({
              text: Math.trunc(cell.value).toString(), //day.value
              style: {
                fontSize: '16px',
                fontWeight:'bold',
                align:'center',
                color: 'rgba(44, 47, 53, 0.6)',
                top: 1
                // border: [`1px transparent`, `1px transparent`,`1px #9EA7C5`,`1px #9EA7C5`]
              }
            });
          }
          // Первый слой фон;
          result = new CanvasTable.Layer({
            style: {
              border:`1px #9EA7C5`,
              backgroundColor: bg,
              zIndex: 0
            },
            children: [layerValue],
            event: {
              onMouseEnter: (e) => {
                this.clearLineDrawRect();
              }
            }
          })
          break;
        case 'plan':
          let circleIcon = ''
          const cellPlan = obj.row.result.find(item => item.day === day) || null;
          let bgCell = []
          if(cellPlan && $this.isNumeric(cellPlan.value)) {
            // COLORS
           // console.log('bgBox',obj);
            circleIcon = this.svgIconsBase64('bgBox',`${obj.row.color}`);
            bgCell = [
              new CanvasTable.Svg({
                  path: circleIcon,
                  style: {
                    width: this.options.canvas_cell_w - 8,
                    height: this.options.canvas_row_height - 8,
                    color: '',
                    padding: 0,
                    zIndex: 100,
                  },
              })
            ];
          }else if(this.hover[`${obj.row.key}_${day}`] === true) {
            circleIcon = this.svgIconsBase64('bgBox','#41A4FF');
            bgCell = [
              new CanvasTable.Svg({
                path: circleIcon,
                style: {
                  width: 32 ,
                  height: 30 ,
                  color: '',
                  padding: 0,
                  zIndex: 100,
                }
              })
            ]
          }else{
            bgCell = [];
          }
          // Первый слой;
          result = new CanvasTable.Layer({
            style: {
              border: planBorder,
              padding: [1,5,1,5],
              backgroundColor: bg,
              zIndex: 1,
            },
            children: [
              // Второй слой
              new CanvasTable.Text({
                width: 38,
                text: cellPlan && $this.isNumeric(cellPlan.value) ? cellPlan.value : '',
                style: {
                  align:'center',
                  zIndex: 10,
                  color: '#000',
                },
                children: bgCell
              })
            ],
            // TODO Ячейка клика;
            event: {
              // TODO onDoubleClick;
              onDoubleClick: (e) =>{
                const editValue = obj.row.result.find((d)=> d.day === day) || null;
                this.focusCell = e.target;

                this.showEditor();
                if(editValue) {
                  this.value = +editValue.value;
                }
                this.cellOn = {...obj, day, value: ''}
                this.clearLineDrawRect();
               // console.log('onDoubleClick',this.cellOn);
              },

              onClick: (e,r) => {
                // Перерисовка;
                const w = window
                const ct = w.ct
               //  ct.source = this.dataTable;
              //  ct.render()

                 const cell = obj.row.result.find(it => it.day === day) || null;
                 if(!cell && this.value !== '' && $this.isNumeric(this.value) && this.cellOn) {
                   console.log('cellOn', this.cellOn);
                   this.cellOn.value = this.value;
                   this.$emit('on-cell-value', this.cellOn);
                   this.hideEditor();
                 }

                 // Выделить ячейки
                 if (cell && !this.show && this.isDrawingMouseEnter === false) {
                   this.focusCell = {...e.target};
                   this.cellOn = {...obj, day, value: cell.value}
                   this.isDrawing = true;
                   const x = e.target.left - 4;
                   const y = e.target.top - 4; //30, 30
                   this.cord.clientY = e.clientY
                   this.cord.x = x
                   this.cord.y = y
                   this.cord.w = this.options.canvas_cell_w - 2.5;
                   this.cord.h = this.options.canvas_row_height - 2.5;
                   this.cord.day = day
                   this.cord.key = obj.row.key
                   // Квадрат;
                   this.lineDrawRect(x, y, this.cord.w, this.cord.h);
                 }else{
                   this.hideEditor()
                 }
                // После выделение ячекйи подвреждает;
                if(this.isDrawingMouseEnter && this.cellOn) {
                  const {days} = this.cord;
                  const resultPlan = obj.row;
                  days.forEach((itDay)=>{
                    const isCellResult = Boolean(obj.row.result.find(item => item.day === itDay))
                    if(!isCellResult){
                      resultPlan.result.push({
                        color: null,
                        day: itDay,
                        icon: null,
                        value: this.cellOn.value
                      })
                    }
                  })
                  obj.row.result = resultPlan.result
                  this.clearLineDrawRect(true);
                  this.updateTable();
                  this.$emit('on-multi-cell-value', obj);
                }

              },

              onMouseEnter: (e) => {
                const el = document.querySelector(".x-canvas-scroll");
                el.style.cursor = 'pointer';
                if(this.isCellHover !== day) {
                  this.isCellHover = day;
                  // Верх / вниз
                  // if(obj.row.key !== this.cord.key) {
                  //  // this.clearLineDrawRect();
                  // }
                  // Выделения
                  if(this.isDrawing) {
                    const w = window
                    const ct = w.ct
                    let left = false

                    if(this.cellOn && obj.row.key === this.cord.key) {
                     // ct.source = this.dataTable;
                      // Левый и правый;
                      left = e.target.left < this.cord.x

                      const { widthCol, sliceDays } = this.moveCell(day, left);
                      const {x,y,h} = this.cord
                      this.cord.w = left ? -widthCol : widthCol;

                      //Рисуем
                      this.lineDrawRect(left ? x + (h + 1) : x, y, this.cord.w, this.cord.h);
                      this.cellOn.day = day;
                      this.cord.days = sliceDays;
                      this.isDrawingMouseEnter = true;
                    }
                    // console.log('onMouseEnter e', e.path);
                    // console.log('onMouseEnter obj', obj);
                    // console.log('onMouseEnter day', day);
                  }
                  //this.hover[day] = true
                  // if(!cellPlan) {
                  //   this.hover[`${obj.row.key}_${day}`] = true;
                  //   const w = window
                  //   const ct = w.ct
                  //   ct.source = this.dataTable;
                  // }
                  // ct.source = this.dataTable;
                  //ct.source = this.dataTable;
                }
              },

              onMouseLeave: (e) => {
                const el = document.querySelector(".x-canvas-scroll");
                el.style.cursor = 'default';

                if(this.isCellHover !== day) {

                  this.isCellHover = day;
                  // this.isCellHover = true

                  this.hover = [];
                  //this.hover[`${obj.row.key}_${day}`] = false;

                  if(!this.isDrawing) {
                    ct.source = this.dataTable;
                  }
                  // if(!cellPlan) {
                  //  // this.hover[day] = false;
                  //   const w = window
                  //   const ct = w.ct
                  //   ct.source = this.dataTable;
                  // }
                }


              },

              onContextMenu: (e) => {
                console.log('onContextMenu',e);
              }
            }
          })
          break;
      }
      return result
    },

    clearLineDrawRect(force = false) {
      if(!force) {
        const w = window
        const ct = w.ct
        ct.render();
      }
      this.isDrawing = false;
      this.isDrawingMouseEnter = false;
      // this.cellOn = null;
    },

    //Рисуем Квадрат;
    lineDrawRect(x, y, w, h) {
      const ct = window.ct
      ct.render();
      this.drawRect(x, y, w, h, {
        fillColor: 'rgba(82,146,247,0.2)',
        borderColor: 'rgb(82,146,247)',
        borderWidth: 1.3
      },ct);

    },

    // Суммировать отчет;
    totalSum(arr = []) {
      if(!arr.length) return 0;
      return arr.map(it => (it.value > 0 && it.value)).reduce((a, b) => a + b, 0) || 0
    },

    // Проверка на Число;
    isNumeric(value) {
      return /^(0|[1-9]\d*)$/.test(value);
    },

    safeResize() {
       this.hideEditor();
    },

    /*---Рамка канвас--*/
    drawRect(x, y, width, height, options,ct) {
      options = Object.assign(
        {
          borderWidth: 1,
          borderColor: undefined,
          fillColor: undefined,
          shadowOffsetX: undefined,
          shadowOffsetY: undefined,
          shadowBlur: 0,
          shadowColor: undefined,
          isBg: false,
          fillStyle: undefined
        },
        options
      );
      ct.ctx.save();
      ct.ctx.beginPath();

      if (options.shadowOffsetX) {
        ct.ctx.shadowOffsetX = options.shadowOffsetX;
      }
      if (options.shadowOffsetY) {
        ct.ctx.shadowOffsetY = options.shadowOffsetY;
      }
      if (options.shadowBlur) {
        ct.ctx.shadowBlur = options.shadowBlur;
      }
      if (options.shadowColor) {
        ct.ctx.shadowColor = options.shadowColor;
      }
      if (options.fillColor) {
        ct.ctx.fillStyle = options.fillColor;
      }
      if (options.borderColor) {
        ct.ctx.lineWidth = options.borderWidth;
        ct.ctx.strokeStyle = options.borderColor;
      }

      if(options.isBg) {
        ct.ctx.fillRect(x + 0.5, y + 0.5, width, height);
      }else{
        ct.ctx.rect(x + 0.5, y + 0.5, width, height);
      }
      if (options.fillColor) {
        ct.ctx.fill();
      }

      if (options.borderColor) {
        ct.ctx.stroke();
      }

      ct.ctx.restore();
    },

    canvasRender() {
      const w = window
      const ct = w.ct
      ct.source = this.dataTable;
      //this.updateTable();
      ct.resize();
    }
  },

  created() {
    const $this = this
    this.dataResult = this.dataGrid;
    const days = this.headerDays()
   // console.log('__data__',this.dataTable); //department
    this.columns = [
      {
      //  fixed: 'left', //'left' | 'right'
        width: this.options.canvas_columns_width,
        title: () => {
          return new CanvasTable.Layer({
            children: [
              new CanvasTable.Svg({
                path: icons['plus'],
                style: {
                  top:0.5,
                  left: 1,
                  width: 32,
                  height: 50,
                  color: 'transparent',
                  border:'transparent',
                },
                event: {
                  onClick: (e) => {
                    const w = window
                    const ct = w.ct
                    this.updateTable();
                  },
                  onMouseEnter: (e) => {
                    //x-canvas-scroll
                    const el = document.querySelector(".x-canvas-scroll");
                    const w = window
                    el.style.cursor = 'pointer';

                    ///  console.log('onMouseEnter',e);
                  },
                  onMouseLeave: (e) => {
                    const el = document.querySelector(".x-canvas-scroll");
                    el.style.cursor = 'default';
                    // console.log('onMouseLeave',e);
                  },
                  onDoubleClick: (event) => {
                    console.log('onDoubleClick',event);
                  }, // Double Click
                  onContextMenu: (event) => {
                    console.log('onContextMenu',event);
                  }
                }
              }),
              new CanvasTable.Text({
                style: {
                  width: 140,
                  fontWeight:'bold',
                  fontSize: '20px'
                },
                text: `Сотрудник`,
                // style: { color: 'gray'}
              }),
              new CanvasTable.Text({
                style: {
                  width: 70,
                  fontWeight:'bold',
                  fontSize: '16px',
                  top: 1,
                },
                text: `1000`, //TODO количество mok
                // style: { color: 'gray'}
              })
            ],
            event: {
              onClick(e) {
                // const w = window
                // w.onCellClick( e, name )
                $this.$emit('on-employee-add', e);
              },
            }
          })
        },
        dataIndex: 'row',
        styleColumn: {
          //  border: [`1px transparent`, `1px #ABB2C6`,`1px transparent`,`1px transparent`]
          border: [`1px transparent`, `1px transparent`,`1px #ABB2C6`,`1px transparent`]
        },
        // onCell: (record, rowIndex) => {
        //
        //   return {
        //     onClick(data) {
        //      console.log(data.target.ctx);
        //     }
        //   }
        // },
        render: (data, record) => this.renderCell({data, record}),
      },
    ]
    days.forEach((d,i)=>{
      const backgroundColor = d === 22 ? '#DBE3FB' : (d === 10 ? '#FFFBEF' :'#EFF2FE')
      this.columns.push(
        {
          align: 'center',
          width: this.options.canvas_cell_w,
          title: d, //d
          day: d,
          index: i,
          dataIndex: 'plan',
          styleColumn: {
            fontSize: '14px',
            fontWeight: 'normal',
            color: 'rgba(115, 129, 163, 0.7)',
            backgroundColor: backgroundColor,
            border: headerLevelBorder(backgroundColor),
            //border: `1px #9EA7C5`,
          },
          render: (data, record) => {
            const backgroundColorCell = d === 22 ? '#E2E9FC' : (d === 10 ? '#FFFBEF' : levelBgRow(record.row.type))
            return this.cellField(record,backgroundColorCell,d);
          }
        },
      )
    })
    this.dataTable = this.generatePersons(true);
    this.heightRowSize();
  },

   async mounted() {
     const $this = this;
     await this.load()

     window.addEventListener( 'resize', this.safeResize );
     document.addEventListener( 'wheel', this.handleScroll, { passive: true } )

     this.$refs.el_input.$el.addEventListener('keydown', function(e) {
      if (e.keyCode === 13 || e.keyCode === 27) {
        if (e.metaKey || e.ctrlKey) return;
        e.preventDefault();
       if($this.cellOn && $this.isNumeric($this.value)) {
         $this.cellOn.value = $this.value
         $this.$emit('on-cell-value', $this.cellOn);
         $this.hideEditor();
       }
      }

    });

  },

  unmounted () {
    window.removeEventListener( 'wheel', this.handleScroll )
  },
  beforeDestroy() {
    window.removeEventListener( 'wheel', this.handleScroll )
  },

  watch: {
    loading(v) {},
    dataGrid(value) {
      this.dataResult = value;
      this.updateTable();
    }
  }

}
</script>

<style lang="scss" scoped>
:root {
  --ViewTable: 1;
}
.el-header, .el-main, .el-footer {
  border: 1px solid;
}
.el-main {
  min-height: 700px;
}

.table_canvas {
  width: 100%;
  height: 600px;
  box-sizing: border-box;
  border: 1px solid #000;

  .column-name {
    border: 1px solid red;
    background: red;
    color: red;
    height: 290px;
    width: 100px;
  }
}

#containerCanvas {
//  height: 100vh;
  width: 100%;
  height: 70vh;
  min-height: 400px;
 // height: 100%;
  //height:600px;
 // height: 600px; //calc(100vh - 160px);
  //width: 1500px;
  //border: 1px solid #000;
  //padding-bottom: 20px;
 // padding-right: 10px;
  //background: red;
  opacity: var(--ViewTable);
  transition: opacity .1s;
 // border-radius: 90px;
}
/deep/ .x-canvas-table > .x-canvas-scroll .x-canvas-scroll-inner {

}
/deep/.x-canvas-table > canvas {
  border-radius: 0px 10px 0px 0px;
  box-shadow: 6px -6px 15px rgba(56, 55, 57, 0.1);
}
.pointer {
  width: 10px;
  height: 10px;
  background: red;
}


$css-prefix: xs-data-grid;
.#{$css-prefix} {
  width: 100%;
  position: relative;
}
.#{$css-prefix}-main {
  width: 100%;
  position: relative;
  box-sizing: border-box;
  overflow: auto; // hidden
  border-right: 1px solid #e1e6eb;
  border-bottom: 1px solid #e1e6eb;
}
.#{$css-prefix}-table {
  text-rendering: auto;
  user-select: none;
  position: relative;
  left: 0px;
  top: 0px;
  cursor: default;
}
.#{$css-prefix}-overlayer {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;

}
.#{$css-prefix}-editor {

  position: absolute;
  top: -10000px;
  left: -10000px;
  text-align: left;
  line-height: 0;
  z-index: 100;
  overflow: hidden;
 // background-color: #fff;
 // border: 2px solid rgb(82,146,247);
  box-sizing: border-box;
  box-shadow: rgba(0, 0, 0, 0.2) 0px 6px 16px;
  pointer-events: auto;
}
.#{$css-prefix}-popup {
  input[type="text"] {
    border: none;
    outline: none;
    border-radius: 0;
  }
}

.popover-cell {
  width: 38px;
  height: 35px;
  background: #fff;
  padding: 2px;
  line-height: normal;
  position: relative;
}
/deep/.x-canvas-table .x-tooltip {
  display: none !important;
  opacity: 0;
}
/deep/.x-canvas-table > .x-canvas-scroll .x-canvas-scroll-inner .x-canvas-scroll-end {
  height: 24px;
}
#circleIcons,#bgBox {
  display: none;
}

.hoverCell {
  width: 32px;
  height: 32px;
  background:#41A4FF;
  opacity: 0.5;
  border-radius: 5px;
  position: absolute;
  top: -10000px;
  left: -10000px;
  text-align: left;
  line-height: 0;
  z-index: 0;
  overflow: hidden;
}

:root {
  --ViewTable: 1;
}

:deep(.el-input__inner) {
  padding: 2px 5px;
  text-align: center;
  font-size: 16px;
  font-family: 'Gilroy';
  color: #000;
  border-color: #41A4FF;
  height: 100%;
}

.input_edit {
  &.error {
    :deep(.el-input__inner) {
      border-color: #EB5757;
    }
  }
}

.el-input--small {
  height: 100%;
}
</style>
