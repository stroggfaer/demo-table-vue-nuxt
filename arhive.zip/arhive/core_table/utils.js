

export function headerDays(m = 31)  {
  //moment("2012-02", "YYYY-MM").daysInMonth() // 29
  const result  = []
  for (let i = 1; i <= m; ++i) {
    result.push(i);
  }
  return result;
}
